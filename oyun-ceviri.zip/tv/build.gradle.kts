plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.berkay.oyunceviri.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.berkay.oyunceviri.tv"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Hafif WebSocket sunucusu (TV tarafı)
    implementation("org.java-websocket:Java-WebSocket:1.5.7")
}
